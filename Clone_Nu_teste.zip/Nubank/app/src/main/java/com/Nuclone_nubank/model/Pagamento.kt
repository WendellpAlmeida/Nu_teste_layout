package com.Nuclone_nubank.model

 data class Pagamento (
     val icone: Int? = null,
     val titulo: String? = null
         )