package com.Nuclone_nubank.model

data class Produto  (
     val texto: String? = null
        )